package com.nau.abstractdemo;

public abstract class Employee {

	protected String name;
	protected double baseSalary;

	public Employee(String name, double baseSalary) {
		this.name = name;
		this.baseSalary = baseSalary;
	}

	protected abstract double calculateSalary();

	protected abstract void displayEmployeeInfo();
}
