package com.nau.abstractdemo;

class Manager extends Employee{
	private double bonus;
	public Manager(String name,double baseSalary, double bonus) {
		super(name,baseSalary);
		this.bonus = bonus;
	}
	@Override
	public double calculateSalary() {
		return baseSalary+bonus;
	}

	@Override
	public void displayEmployeeInfo() {
		System.out.println("NAme : " + name);
		System.out.println("Base Salary : " + baseSalary);
		System.out.println("Bonus : " + bonus);
		System.out.println("Total Salary : " + calculateSalary());
	}
	
}