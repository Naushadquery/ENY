package com.nau.abstractdemo;

public class MainApp {
	
	public static void main(String[] args) {
		
		Employee e1 = new Manager("Naushad", 10000, 5000);
		
		Employee e2 = new Programmer("Akhtar", 20000, 1000, 5);
		displayEmployeeData(e2);
		displayEmployeeData(e1);
	}
	
	static void displayEmployeeData(Employee e) {
		e.displayEmployeeInfo();
	}
}
