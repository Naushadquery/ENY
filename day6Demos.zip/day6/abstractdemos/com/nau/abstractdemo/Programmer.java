package com.nau.abstractdemo;

class Programmer extends Employee{
	
	private double hourlyRates;
	private Integer extraHours;
	
	public Programmer(String name,double baseSalary, double hourlRates, Integer extraHours) {
		super(name,baseSalary);
		this.hourlyRates = hourlRates;
		this.extraHours = extraHours;
	}
	@Override
	public double calculateSalary() {
		return baseSalary+(hourlyRates*extraHours);
	}

	@Override
	public void displayEmployeeInfo() {
		System.out.println("NAme : " + name);
		System.out.println("Base Salary : " + baseSalary);
		System.out.println("Extra Hours : " + extraHours);
		System.out.println("Total Extra Hours " + hourlyRates);
		System.out.println("Total Salary : " + calculateSalary());
	}
}