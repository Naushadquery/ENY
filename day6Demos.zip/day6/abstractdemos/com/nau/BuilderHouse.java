package com.nau;

public abstract class BuilderHouse {

	public BuilderHouse() {
		System.out.println("BuilderHouse Object Created");
	}

	public void livingRoom() {
		System.out.println("Normal Living room with no furniture");
	} // method body // implemention

	public void bedRoom() {
		System.out.println("Normal Bedroom with Floor Mat, no bed");
	}

	public  abstract void kitchen();

	public void bathRoom() {
		System.out.println("Normal Bathroom with one bucket and mug");
	}

}

final class HotelApartment{
	public void livingRoom() {
		System.out.println(" Living room with TV and Sofa");
	} // method body // implemention

	public void bedRoom() {
		System.out.println("Bedroom with Spring Bonel MAttress");
	}

	public void bathRoom() {
		System.out.println("Bathroom with Jaguar Fittings");
	}
}