package com.nau;

import java.awt.Toolkit;

public class Demo {
	
	public static void main(String[] args) {
		
//		RK rk = new RK();
//		rk.bathRoom();
//		rk.livingRoom();
//		rk.bedRoom();
//		rk.kitchen();
		
		
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		toolkit.getScreenSize();
		
		
		
//		HotelApartment apartment = new HotelApartment();
//		apartment.livingRoom();
	}

}
abstract class NaushadHouse extends BuilderHouse{ // Inheritence of type IS-A
	
	@Override
	public void kitchen() {
		System.out.println("Kitchen with platform");
	}
}

 class RK extends NaushadHouse{
	public void bathRoom() {
		System.out.println("Jacuzzi , Sauna, Steam ,Bathroom with one bucket and mug");
	}
}

