package com.nau.interfacedemo;

public interface Fridge {
	Integer size();
	String brand();
}
