package com.nau.interfacedemo;

public class House {
	
	public void setFridge(Fridge fridge) {
		Integer size = fridge.size();
		String brand = fridge.brand();
		System.out.println(brand + " fridge of size : " + size + " has been setup" );
	}
}
