package com.nau.interfacedemo;

class LG implements Fridge{

	@Override
	public Integer size() {
		return 500;
	}
	@Override
	public String brand() {
		return "LG";
	}
}
class Samsung implements Fridge{

	@Override
	public Integer size() {
		return 670;
	}
	@Override
	public String brand() {
		return "Samsung Neigbour Shop";
	}
}
public class InterfaceDemo {
	
	static Fridge fridge6 = new Fridge() {
		@Override
		public Integer size() {
			return 300;
		}
		@Override
		public String brand() {
			return "Haier";
		}
	};
	
	
	static class BPL implements Fridge{

		@Override
		public Integer size() {
			return 670;
		}
		@Override
		public String brand() {
			return "BPL Neigbour Shop";
		}
	}
	
	public static void main(String[] args) {
		Fridge fridge1 = new LG();
		Fridge fridge2 = new Samsung();
		Fridge fridge3 = new BPL();
		House house = new House();
		house.setFridge(fridge1);
		house.setFridge(fridge2);
		house.setFridge(fridge3);
		class Voltas implements Fridge{

			@Override
			public Integer size() {
				return 670;
			}
			@Override
			public String brand() {
				return "voltas Neigbour Shop";
			}
		}
		Fridge fridge4 = new Voltas();
		house.setFridge(fridge4);
		
		Fridge fridge5 = new Fridge() {
			@Override
			public Integer size() {
				return 800;
			}
			@Override
			public String brand() {
				return "Panasonic";
			}
		};
		
		house.setFridge(fridge5);
		house.setFridge(fridge6);
		house.setFridge(new Fridge() {
			@Override
			public Integer size() {
				return 800;
			}
			@Override
			public String brand() {
				return "Hitachi";
			}
		});
		
		
//		Impl1 ia = new Impl1();
//		ia.iaMethod();
//		ia.iCommon();
//		Impl2 ib = new Impl2();
//		ib.ibMethod();
//		ib.icMethod();
//		ib.iCommon();
	}
}

class Impl2 implements IA, IB {
	@Override
	public void iaMethod() {
		System.out.println("iamethod in Impl");
	}

	@Override
	public void ibMethod() {
		System.out.println("ibmethod in Impl");
	}

	@Override
	public void icMethod() {
		System.out.println("icmethod in Impl");
	}

	@Override
	public void iCommon() {
		System.out.println("ICommon in Impl2");
	}
}

class Impl1 implements IA, IB {
	@Override
	public void iaMethod() {
		System.out.println("iamethod in Impl");
	}

	@Override
	public void ibMethod() {
		System.out.println("ibmethod in Impl");
	}

	@Override
	public void icMethod() {
		System.out.println("icmethod in Impl");
	}

	@Override
	public void iCommon() {
		System.out.println("iCommon in Impl");

	}
}

interface IA {
	void iaMethod();

	void iCommon();
}

interface IB extends IC {
	void ibMethod();

	void iCommon();
}

interface IC {
	void icMethod();
}
