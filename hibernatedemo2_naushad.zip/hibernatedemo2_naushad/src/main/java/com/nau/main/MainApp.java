package com.nau.main;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.nau.dao.EmployeeDao;
import com.nau.entity.EmployeeEntity2;
import com.nau.util.HibernateUtil;

public class MainApp {

	public static void main(String[] args) {
		EmployeeDao dao = new EmployeeDao();
//		Address address1 = new Address("Bengal", "Kolkatta");
//		EmployeeEntity e1 = new EmployeeEntity("naushad",address1);
		// dao.saveEmployee(e1);
		// dao.getEmployeeById(10);
//		Set<String> emails = new HashSet<String>();
//		emails.add("a");
//		emails.add("d");
//		emails.add("d");
//		EmployeeEntity2 e1 = new EmployeeEntity2("naushad", emails);
//		dao.saveEmployee(e1);
		// dao.getEmployeeById_two(12);
		
		dao.savePerson();
		//HibernateUtil.closeFactory();
	}

}
