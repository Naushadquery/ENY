package com.nau.util;

import java.sql.SQLException;

import org.h2.tools.Server;

public class H2DatabaseManager {
	public static void startDB() {
		try {
			Server.createTcpServer("-tcpPort", "9092", "-tcpAllowOthers").start();
			System.out.println("H2 Server Started");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void stopDB() {
		try {
			Server.shutdownTcpServer("tcp://localhost:9092", "", true, true);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	static {
		try {
			Class.forName("org.h2.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		H2DatabaseManager.startDB();
	}
}