package com.nau.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;

import com.nau.dao.EmployeeDao;
import com.nau.entity.EmployeeEntity;
import com.nau.model.EmployeeDTO;

public class EmployeeService {

	private EmployeeDao dao = new EmployeeDao();
	private ModelMapper mapper = new ModelMapper();

	public void addEmployee(EmployeeDTO employee) {
		System.out.println(employee);
//		EmployeeEntity employeeEntity = new EmployeeEntity();
//		employeeEntity.setId(employee.id());
//		employeeEntity.setName(employee.name());
//		employeeEntity.setCity(employee.city());
//		dao.saveEmployee(employeeEntity);
		employee.setName(employee.getName().toUpperCase());
		EmployeeEntity employeeEntity = mapper.map(employee, EmployeeEntity.class);
		
	
		
		dao.saveEmployee(employeeEntity);

	}

	public List<EmployeeDTO> getEmpoyeesByCity(String city) {
		List<EmployeeDTO> employeeDTOs = dao.getEmpoyeesByCity(city);
		employeeDTOs.forEach(System.out::println);
		return null;
	}	

	public void getEmployee(Integer id) {
		EmployeeDTO dto = dao.getEmployeeById(id);
		
	}

	public void getEmployeeByName(String name) {
		dao.getEmpoyeesByName(name);
		
	}

}
