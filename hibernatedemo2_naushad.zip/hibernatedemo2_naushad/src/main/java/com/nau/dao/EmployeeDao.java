package com.nau.dao;

import java.util.List;
import java.util.Set;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;

import com.nau.entity.Account;
import com.nau.entity.EmployeeEntity;
import com.nau.entity.EmployeeEntity2;
import com.nau.entity.Person;
import com.nau.model.EmployeeDTO;
import com.nau.util.HibernateUtil;

public class EmployeeDao {

	private ModelMapper mapper = new ModelMapper();
	private SessionFactory factory = HibernateUtil.getFactory();
	
	public String saveEmployee(EmployeeEntity employeeEntity) {
		Session session = factory.openSession();
		session.getTransaction().begin();
		session.persist(employeeEntity);
		session.getTransaction().commit();
		session.close();
		return "ok";
	}
	public String saveEmployee(EmployeeEntity2 employeeEntity) {
		Session session = factory.openSession();
		session.getTransaction().begin();
		session.persist(employeeEntity);
		session.getTransaction().commit();
		session.close();
		
		return "ok";
		
	}


//	public List<EmployeeDTO> getEmployeeByCity(String city){
//		
//		
//		
//		
//		
//		return null;
//	}
	public List<EmployeeDTO> getEmpoyeesByName(String name) {
		Session session = HibernateUtil.getSession();
//		Query q = session.createNamedQuery("findByName", EmployeeEntity.class);
//		q.setParameter("name", name);
		
		Query q = session.createNativeQuery("select * from employeetable where empname='"+ name +"'", EmployeeEntity.class);
		
		//session.create
		List<EmployeeEntity> list = q.getResultList();
//		List<EmployeeDTO> dtos = new ArrayList<EmployeeDTO>();
//		mapper.map(list, dtos);
		list.forEach(System.out::println);
		List<EmployeeDTO> dtos = mapper.map(list, new TypeToken<List<EmployeeDTO>>() {
		}.getType());
		session.close();
		return dtos;
	}

	public List<EmployeeDTO> getEmpoyeesByCity(String city) {
		Session session = HibernateUtil.getSession();
//		String q1 = "from EmployeeEntity e where e.city='" + city + "'"; // HQL
//		Query q = session.createQuery(q1, EmployeeEntity.class);

		Query q =  session.createNamedQuery("findByCity", EmployeeEntity.class);
		q.setParameter("city", city);
		List<EmployeeEntity> list = q.getResultList();
//		List<EmployeeDTO> dtos = new ArrayList<EmployeeDTO>();
//		mapper.map(list, dtos);
		list.forEach(System.out::println);
		List<EmployeeDTO> dtos = mapper.map(list, new TypeToken<List<EmployeeDTO>>() {
		}.getType());
		return dtos;
	}

	public EmployeeDTO getEmployeeById_two(Integer id) {
		
		Session session1 = factory.openSession();
		
		EmployeeEntity2 e =session1.get(EmployeeEntity2.class, id);
		System.out.println(e);
		Set<String> emails = e.getEmail();
		emails.forEach(System.out::println);
		session1.close();
		return null;

	}
	
	public EmployeeDTO getEmployeeById(Integer id) {
	
		Session session1 = factory.openSession();
		
		EmployeeEntity e =session1.get(EmployeeEntity.class, id);
		System.out.println(e);
		System.out.println(e.getAddress().getCity());
		session1.close();
		return null;

	}
	public void savePerson() {
		Account account = new Account();
		Person person = new Person();
		person.setName("Naushad");
		Session session = factory.openSession();
		session.getTransaction().begin();
		session.persist(person);
		session.persist(account);
		session.getTransaction().commit();
		session.close();
	}

}
