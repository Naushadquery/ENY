package com.nau.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//public class Employee {
//	
//	Integer id;
//	String name ;
//	String city ;
//	
//	
//}

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeDTO {

	private Integer id;
	private String name;
	private String city;
	private List<String> certiticates;

	public EmployeeDTO(String name, String city) {
		this.name = name;
		this.city = city;
	}
}
