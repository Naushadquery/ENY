package com.nau.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data // getter / setter / tostring , equals, hashcode
@Table(name = "employeetable22")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE) // second level caching
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "empid")
	private Integer id;
	@Column(name = "empname")
	private String name;

	@Embedded
	private Address address;
	
	public EmployeeEntity(String name, Address address) {
		super();
		this.name = name;
		this.address = address;
	}

//	@ElementCollection
//	private List<String> certificates;

}
