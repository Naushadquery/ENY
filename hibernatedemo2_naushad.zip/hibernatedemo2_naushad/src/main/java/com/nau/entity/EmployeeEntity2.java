package com.nau.entity;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data // getter / setter / tostring , equals, hashcode
@Table(name = "employeetable_two")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE) // second level caching
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeEntity2 {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "empid")
	private Integer id;
	@Column(name = "empname")
	private String name;
	
	@ElementCollection
	private Set<String> email;
	
	public EmployeeEntity2(String name,Set<String> email) {
		super();
		this.name = name;
		this.email = email;
		
	}

//	@ElementCollection
//	private List<String> certificates;

}
