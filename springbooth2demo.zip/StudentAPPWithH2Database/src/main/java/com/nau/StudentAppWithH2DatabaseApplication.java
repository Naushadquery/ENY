package com.nau;

import org.apache.catalina.core.ApplicationContext;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
@CrossOrigin
public class StudentAppWithH2DatabaseApplication {
	
	@Autowired
	private StudentService studentService;
	

	public static void main(String[] args) {
	ConfigurableApplicationContext context =	SpringApplication.run(StudentAppWithH2DatabaseApplication.class, args);
	StudentService service = context.getBean(StudentService.class);
	service.addStudent(new StudentDTO(1, "naushad"));
	service.addStudent(new StudentDTO(2, "akhtar"));
	service.addStudent(new StudentDTO(3, "munna"));
	
	}

	@GetMapping
	public String home() {
		return "Welcome to Student APP";
	}
	
	@PostMapping("{name}") // http://localhost:8080/?
	public String greet(@PathVariable("name") String name) {
		return "Greetings From Naushad, You are most welcomed : " + name;
	}
	
}
