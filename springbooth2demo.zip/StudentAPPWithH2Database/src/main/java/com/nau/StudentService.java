package com.nau;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class StudentService {

	@Autowired
	private StudentDao studentDao;

	private ModelMapper mapper = new ModelMapper();

	public void addStudent(StudentDTO student) {
		log.info("In Service Method {}", student);
		student.setName(student.getName().toUpperCase());
		StudentEntity entity = mapper.map(student, StudentEntity.class);
		studentDao.addStudent(entity);
	}
	
	public boolean verifyById(Integer id) {
		return studentDao.verifyId(id);
	}
	
	public boolean deleteStudent(Integer id) {
		return studentDao.deleteStudent(id);
	}
}
