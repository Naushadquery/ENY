package com.nau;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class StudentDao {

	@Autowired
	private StudentEntityRepository repository;

	public StudentEntity addStudent(StudentEntity student) {
		return repository.save(student);
	}

	public List<StudentEntity> getAllStudents() {
		return repository.findAll();
	}

	public boolean verifyId(Integer id) {
		return repository.existsById(id);
	}
	
	public boolean deleteStudent(Integer id) {
		if (repository.existsById(id)) {
			repository.deleteById(id);
			return true;
		}
		return false;
	}
}
