package com.nau.view;

import java.util.Scanner;
import java.util.logging.Logger;

import com.nau.service.LoginService;

public class LoginView {
	
	private static final Logger log = Logger.getLogger(LoginView.class.getName());
	private Scanner input = new Scanner(System.in);
	private LoginService loginService = new LoginService();
	
	public LoginView() {
		
		loginCredentials();
	}

	private void loginCredentials() {
		log.info("Entering logincredentials method");
		System.out.println("Please Enter Login Credentials (Userid - 3 digits)");
		System.out.println("User ID: ");
		String userId = input.next();
		
		System.out.println("Password: ");
		String password = input.next();
		log.info("User ID : " + userId);
		log.info("Password : " + password);
		
		String message = loginService.verifyUser(userId,password);
		System.out.println(message);
		
		log.info("Returning logincredentials method");	
	}
	

}
