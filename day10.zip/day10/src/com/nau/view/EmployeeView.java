package com.nau.view;

public class EmployeeView {
	
	public EmployeeView() {
		System.out.println("In Employee View");
	}

}
