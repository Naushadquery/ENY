package com.nau.view;

import java.util.Scanner;

import com.nau.dao.LoginDao;
import com.nau.model.Login;

public class AdminView {

	private Scanner input = new Scanner(System.in);
	private LoginDao loginDao  = new LoginDao();
	public AdminView() {
		System.out.println("Admin View");
		
		viewPanel();
	}

	private void viewPanel() {
		System.out.println("1. Add User");
		System.out.println("Enter User ID");
		String userId = input.next();
		System.out.println("Enter Password");
		String password = input.next();
		System.out.println("Enter Type");
		String type= input.next();
		
		System.out.println("Enter First Name : ");
		String fName = input.next();
		System.out.println("Enter Lass Name");
		String lName = input.next();
		
		Login login = new Login(Integer.valueOf(userId),password,type,fName,lName);
		loginDao.addLogin(login);
		System.out.println("Saved");
		
		
	}

}
