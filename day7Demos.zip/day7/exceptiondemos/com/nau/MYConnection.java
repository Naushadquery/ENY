package com.nau;

public class MYConnection implements AutoCloseable{
	
	String url;
	
	public MYConnection(String url) {
		this.url = url;
	}

	public void add(int i) {
		this.url  = this.url + i;
	}
	@Override
	public void close() throws Exception {
		System.out.println("URL COnnection Closed and Reset");
	}
	

}
