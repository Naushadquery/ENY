package com.nau;

import com.nau.exception.PinNumberInvalidExceprion;

public class BankUSer {
 
	public static void main(String[] args) throws PinNumberInvalidExceprion {
		SBIBAnk bank = new SBIBAnk();
		bank.withdraw(50000);
		
	}
}
