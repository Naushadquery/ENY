package com.nau;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class TryWithResourceDemo {

	public static void main(String[] args) throws FileNotFoundException {

		try (FileInputStream fis = new FileInputStream("abc.txt"); MYConnection connection = new MYConnection("asdf")) {
			connection.add(12);
			System.out.println("Exiting");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		Scanner scanner = new Scanner(new File("abc.txt"));
		String s = scanner.nextLine();
		System.out.println(s);
		scanner.close();

		Scanner scanner1 = new Scanner(new File("abc.txt"));
		String s1 = scanner1.nextLine();
		System.out.println(s1);

		Scanner input = new Scanner(System.in);

		System.out.println(input.nextInt());
		input.close();

		Scanner input1 = new Scanner(System.in);

		System.out.println(input1.nextInt());
	}
}
