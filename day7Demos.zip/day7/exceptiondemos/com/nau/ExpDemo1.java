package com.nau;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class ExpDemo1 {

	public static void main(String[] args) {

		// Runtime // Compile Time
		// unchecked // checked

		// try , catch, finally, throw, throws
		System.out.println("start");
		FileInputStream fis = null;
		try {
			fis = new FileInputStream("abc.txt");
			try {
				fis.read();
			} catch (IOException e) {
				e.printStackTrace();
			}
			int x = 8;
			int y = 1;
			int z = x / y;
			System.out.println(z);
		} catch (IOException e) {
			System.out.println("FNF");
		} finally {
			try {
				if (fis != null) {
					fis.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			System.out.println("finally");
		}
		System.out.println("end");
	}

}
