package com.nau;

import com.nau.exception.PinNumberInvalidExceprion;

public class SBIBAnk {
	
	private ATMBank atmBank = new ATMBank();
	
	public void withdraw(Integer pin) throws PinNumberInvalidExceprion {
		Boolean b = atmBank.inputPIN(pin);
		System.out.println(b);
	}
 
}
