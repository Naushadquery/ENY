package com.nau;

public class EXPDemos {
	
	static String name;
	
	public static void main(String[] args) {
		
//		Object obj = new String("HEllo");
//		
//		Integer i = (Integer)obj;
		
		Integer id = Integer.parseInt(args[0]);
		String fname = args[1];
		String lname = args[2];
		
		Student student = new Student();
		student.setId(id);
		student.setFname(fname);
		displayStudent(student);
	}

	private static void displayStudent(Student student) {
		System.out.println(student);
		System.out.println(student.getLname().toUpperCase());
	}

}
