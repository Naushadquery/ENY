package com.nau.exception;


// EmployeeIdAlreadyExistException

public class PinNumberInvalidExceprion extends Exception{

	public PinNumberInvalidExceprion(String msg) {
		super(msg);
	}
}
