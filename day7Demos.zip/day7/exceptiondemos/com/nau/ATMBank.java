package com.nau;

import com.nau.exception.PinNumberInvalidExceprion;

public class ATMBank {

	public Boolean inputPIN(Integer pinNo) throws PinNumberInvalidExceprion {
		if( pinNo > 1000 && pinNo < 10000) {
			return true;
		}
		else { 
			throw new PinNumberInvalidExceprion("Pin Enter " + pinNo +" is Wrong");
		}
	}

}
