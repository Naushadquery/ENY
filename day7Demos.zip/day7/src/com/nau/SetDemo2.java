package com.nau;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

public class SetDemo2 {
	
	
	public static void main(String[] args) {
		Employee employee1 = new Employee(1, "Naushad", LocalDate.of(1974, 7, 25), EmployeeType.CEO);
		Employee employee2 = new Employee(2, "RAvi", LocalDate.of(1989, 7, 25), EmployeeType.CTO);
		Employee employee3 = new Employee(3, "Vishnu", LocalDate.of(1999, 7, 25), EmployeeType.DEVELOPER);
		Employee employee4 = new Employee(4, "Rama", LocalDate.of(2001, 7, 25), EmployeeType.MANAGER);
		Employee employee5 = new Employee(1, "As", LocalDate.of(1974, 7, 25), EmployeeType.CEO);

		System.out.println("=============== Set ================");
		Set<Employee> names = new HashSet<>(); // In set collection duplicates are not allowed
		System.out.println(names.add(employee1));
		System.out.println(names.add(employee2));
		System.out.println(names.add(employee3));
		System.out.println(names.add(employee4));
		System.out.println(names.add(employee5));
		List<Employee> list = new ArrayList<Employee>(names);
		Comparator<Employee> byName = new Comparator<Employee>() {
			@Override
			public int compare(Employee o1, Employee o2) {
				return o1.getName().compareTo(o2.getName());
			}
		};
		Collections.sort(list,byName);
		for(Employee n : list) {
			System.out.println(n);
		}
//		
//		Comparator<Employee> byName = new Comparator<Employee>() {
//			@Override
//			public int compare(Employee o1, Employee o2) {
//				return o1.getName().compareTo(o2.getName());
//			}
//		};
//		Set<Employee> names = new TreeSet<>(); // In set collection duplicates are not allowed
//		System.out.println(names.add(employee1));
//		System.out.println(names.add(employee2));
//		System.out.println(names.add(employee3));
//		System.out.println(names.add(employee4));
//		System.out.println(names.add(employee5));
//		for(Employee n : names) {
//			System.out.println(n);
//		}
		
		System.out.println("=========================== Sort By Name ===========================");
	
	
//		
//		System.out.println("=====================================================");
//		Set<Integer> numbers = new LinkedHashSet<Integer>();
//		numbers.add(1);
//		numbers.add(2);
//		numbers.add(4);
//		numbers.add(3);
//		numbers.add(4);
//		for(Integer i : numbers) {
//			System.out.println(i);
//		}
//		System.out.println("=====================================================");
//		
		
	}
}
