package com.nau;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

public class SetDemo {
	
	
	public static void main(String[] args) {
		
		System.out.println("=============== Set ================");
		Set<String> names = new HashSet<>(); // In set collection duplicates are not allowed
		System.out.println(names.add("b"));
		System.out.println(names.add("aa"));
		System.out.println(names.add("cc"));
		System.out.println(names.add("d"));
		System.out.println(names.add("aa"));
		System.out.println(names.add("b"));

		for(String n : names) {
			System.out.println(n);
		}
		
		for(String n : names) {
			System.out.println(n);
		}
		
		System.out.println("=====================================================");
		Set<Integer> numbers = new LinkedHashSet<Integer>();
		numbers.add(1);
		numbers.add(2);
		numbers.add(4);
		numbers.add(3);
		numbers.add(4);
		for(Integer i : numbers) {
			System.out.println(i);
		}
		System.out.println("=====================================================");
		
		SortedSet<String>  cities = new TreeSet<String>(names);
		cities.add("kochi");
		cities.add("mumbai");
		cities.add("goa");
		cities.add("munnar");
		cities.add("goa");
		for(String city : cities) {
			System.out.println(city);
		}
	}
}
