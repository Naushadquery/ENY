package com.nau;

public enum EmployeeType {

	MANAGER, CEO, DEVELOPER, CTO

}
