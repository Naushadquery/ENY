package com.nau;

import java.time.LocalDate;
import java.util.Objects;

public class Employee implements Comparable<Employee>{
	private int id;
	private String name;
	private LocalDate dob;
	private EmployeeType employeeType;
	
	public Employee() {
	}

	public Employee(int id, String name, LocalDate dob, EmployeeType employeeType) {
		super();
		this.id = id;
		this.name = name;
		this.dob = dob;
		this.employeeType = employeeType;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public EmployeeType getEmployeeType() {
		return employeeType;
	}

	public void setEmployeeType(EmployeeType employeeType) {
		this.employeeType = employeeType;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", dob=" + dob + ", employeeType=" + employeeType + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		return id == other.id;
	}

	@Override
	public int compareTo(Employee emp) {
		
		return emp.getId()-this.id  ;
		//return this.name.compareTo(emp.getName());
	}
}
