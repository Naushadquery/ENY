package com.nau;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Properties;

public class PropertiesDemo {
	
	public static void main(String[] args) throws IOException {
		
		Properties props = new Properties();
		props.load(new FileReader("mp.properties"));
		System.out.println(props.getProperty("name"));
		
//		props.put("name", "naushad");
//		props.put("city", "Mumbai");
//		Enumeration<Object> en =  props.keys();
//		while(en.hasMoreElements()) {
//			String k = (String)en.nextElement();
//			System.out.println( k + " : " + props.getProperty(k));
//		}
//		
//		props.store(new FileWriter("myprops.properties"),"MY NAmes");
	}

}
