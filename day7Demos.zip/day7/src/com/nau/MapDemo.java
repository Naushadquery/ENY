package com.nau;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MapDemo {
	
	public static void main(String[] args) {
		Employee e1 = new Employee(1, "Naushad", LocalDate.of(1974, 7, 25), EmployeeType.CEO);
		Employee e2 = new Employee(2, "RAvi", LocalDate.of(1989, 7, 25), EmployeeType.CTO);
		Employee e3 = new Employee(3, "Vishnu", LocalDate.of(1999, 7, 25), EmployeeType.DEVELOPER);
		Employee e4 = new Employee(4, "Rama", LocalDate.of(2001, 7, 25), EmployeeType.MANAGER);
		Employee e5 = new Employee(1, "As", LocalDate.of(1974, 7, 25), EmployeeType.CEO);
		Map<Integer, Employee> employees = new HashMap<>();
		System.out.println(employees.put(e1.getId(), e1)); // null
		System.out.println(employees.put(e2.getId(), e2));// Apple
		System.out.println(employees.put(e3.getId(), e3)); //
		System.out.println(employees.put(e3.getId(), e4));
		System.out.println(employees.put(e4.getId(), e5));
		System.out.println(employees.put(e5.getId(), e5));
		System.out.println("==================");
		
		
		
		
//		Map<Integer, String> map = new HashMap<Integer, String>();
//		System.out.println(map.put(1, "Apple")); // null
//		System.out.println(map.put(2, "Chickoo"));// Apple
//		System.out.println(map.put(3, "Banana")); //
//		System.out.println(map.put(4, "Grape"));
//		System.out.println(map.put(5, "Orange"));
//		System.out.println("==================");
//		
//		Set<Integer> key = map.keySet();
//		for(Integer k : key) {
//			//System.out.println(k);
//			String s = map.get(k);
//			System.out.println(s);
//		}
	}

}
