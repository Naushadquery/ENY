package com.nau.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.nau.vo.DepartmentVO;

@FeignClient(url = "http://192.168.29.51:2222",value="Department-Client")
public interface DepartmentClient {
	
	@GetMapping("/department/byid/{deptId}")
	public DepartmentVO getDepartment(@PathVariable Integer deptId); 
	
}
