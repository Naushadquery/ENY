package com.nau.vo;

import java.io.Serializable;

import com.nau.entity.EmployeeEntity;

import lombok.Data;

@Data
public class EmployeeDepartmentVO implements Serializable{
	
	private EmployeeEntity employeeEntity;
	private DepartmentVO departmentVO;

}
