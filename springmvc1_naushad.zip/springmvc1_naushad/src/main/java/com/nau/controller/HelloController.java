package com.nau.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nau.model.User;


@Controller
@RequestMapping("/home")
public class HelloController {

	public HelloController() {
		System.out.println("Hello Controller");
	}
	@GetMapping
	//@ResponseBody
	public String home() {
		return "index";
	}
	
	@GetMapping("/hello")// http://localhost:3306/springmvc1_naushad/home/hello?uname=akhtar&password=asdfsa
	public String hello(@ModelAttribute User user) {
		System.out.println(user);
		return "welcome";
	}
}
