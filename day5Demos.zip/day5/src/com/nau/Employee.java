package com.nau;

public class Employee {
}
class Manager extends Employee {
	public void managerSalary() {
		System.out.println("manager salary");
	}
}
class CEO extends Employee {
	public void ceoSalary() {
		System.out.println("ceo salary");
	}
}
class Gift {
}
class IWatch extends Gift {
	public void iwatchOn() {
		System.out.println("Iwathch swticed on");
	}
}
class IPhone extends Gift {
	public void iphoneOn() {
		System.out.println("Iphone swticed on");
	}
}
