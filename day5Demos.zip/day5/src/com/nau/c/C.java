package com.nau.c;

public class C extends Object{

	public C() {
		super();
		System.out.println("object of class C created with default constructor");
	}

	public C(int i) {
		super();
		System.out.println("object of class C created with paramatrized constructor : " + i);
	}

	public void methodC() {
		System.out.println("methodC in class C");
	}
	public void methodCC() {
		System.out.println("methodCC in class C");
	}
}
