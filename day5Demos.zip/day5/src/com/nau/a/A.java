package com.nau.a;

import com.nau.b.B;

public class A extends B{
	int ax = 10;
	public A() {
		super();
		System.out.println("object of class A created with default constructor");
	}
	public A(int i) {
		super();// B(i)
		System.out.println("object of class A created with paramatrized constructor : " + i);
	}
	public void methodA() {
		bx =50;
		//methodBProctedted();
		//B b = new B();
		//b.methodBProctedted();
		
		System.out.println("methodA in class A");
	}
	public void methodB() {
		System.out.println("methodB in class A");
	}
	public void methodAA() {
		System.out.println("methodAA in class A");
	}
}
