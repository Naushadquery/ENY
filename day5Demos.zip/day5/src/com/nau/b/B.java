package com.nau.b;

import com.nau.c.C;

public class B extends C{
	protected int bx = 10;
	public B() {
		super();
		System.out.println("object of class B created with default constructor");
	}
	public B(int i) {
		super();
		System.out.println("object of class B created with paramatrized constructor : " + i);
	}
	protected void methodBProctedted() {
		System.out.println("methodBProctected in class B");
	}
	void methodBDefault() {
		System.out.println("methodBDefault in class B");
	}
	private void methodBPrivate() {
		System.out.println("methodBPrivate in class B");
	}
	public void methodB() {
		System.out.println("methodB in class B");
	}
	public void methodBB() {
		System.out.println("methodBB in class B");
	}
}
