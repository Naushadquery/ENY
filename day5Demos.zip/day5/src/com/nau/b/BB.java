package com.nau.b;

import com.nau.c.C;

public class BB extends C{
	protected int bx = 10;
	public BB() {
		super();
		System.out.println("object of class BB created with default constructor");
	}
	public BB(int i) {
		super();
		System.out.println("object of class BB created with paramatrized constructor : " + i);
	}
	protected void methodBBProctedted() {
		System.out.println("methodBBProctected in class BB");
	}
	void methodBBDefault() {
		B b = new B();
		b.methodBProctedted();
		
		System.out.println("methodBBDefault in class BB");
	}
	private void methodBBPrivate() {
		System.out.println("methodBBPrivate in class BB");
	}
	public void methodBB() {
		System.out.println("methodBB in class BB");
	}
	public void methodBBBB() {
		System.out.println("methodBBBB in class BB");
	}
}
