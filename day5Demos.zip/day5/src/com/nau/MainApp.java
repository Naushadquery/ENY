package com.nau;

import com.nau.b.B;

public class MainApp {
	public static void main(String[] args) {
//		A a = new A();
//		a.methodA();
//		
//		showObject(a);
		Employee e = new Manager();
		Employee e1 = new CEO();
		IPhone iPhone = new IPhone();
		IWatch iWatch = new IWatch();
		displayGift(iPhone);
		displayGift(iWatch);
	}

	public static void displayGift(Gift gift) {
		System.out.println(gift.getClass().getName());
		if (gift instanceof IPhone) {
			IPhone iPhone = (IPhone) gift;
			iPhone.iphoneOn();
		} else if (gift instanceof IWatch) {
			IWatch iWatch = (IWatch) gift;
			iWatch.iwatchOn();
		}
	}

	public static void showObject(Object a) {
//		String name = obj.getClass().getName();
//		System.out.println(name);
//		B a = (B)obj;
//		a.methodB();
//		a.methodCC();
	}
}