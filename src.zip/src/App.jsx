import { useState } from "react";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./App.css";
import { NoPage } from "./pages/NoPage";
import { Layout } from "./pages/Layout";
import { Home } from "./pages/Home";
import { Blogs } from "./pages/Blogs";
import { Calculator } from "./pages/Calculator";
import { Contact } from "./pages/Contact";
import { MyForm } from "./pages/MyForm";
import { MyForm2 } from "./pages/MyForm2";

function App() {
  return (
    // <div>
    //   <div>
    //     <h1>Routing Demo</h1>
    //   </div>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="home" element={<Home />} />
          <Route path="contact" element={<Contact />} />
          <Route path="blogs" element={<Blogs />} />
          <Route path="calculator" element={<Calculator />} />
          <Route path="myform" element={<MyForm />} />
          <Route path="myform2" element={<MyForm2 />} />
        </Route>
      </Routes>
    </BrowserRouter>
    // </div>
  );
}

export default App;
