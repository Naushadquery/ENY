import { useState } from "react";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./App.css";
import { NoPage } from "./pages/NoPage";
import { Layout } from "./pages/Layout";
import { Home } from "./pages/Home";
import { Blogs } from "./pages/Blogs";
import { Calculator } from "./pages/Calculator";

function App() {
  return (
    // <div>
    //   <div>
    //     <h1>Routing Demo</h1>
    //   </div>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="home" element={<Home />} />
          <Route path="blogs" element={<Blogs />} />
          <Route path="calculator" element={<Calculator />} />
        </Route>
      </Routes>
    </BrowserRouter>
    // </div>
  );
}

export default App;
