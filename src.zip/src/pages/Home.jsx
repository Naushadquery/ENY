import { memo, useState } from "react";

function Home() {
  const [serverMessage, setServerMessage] = useState("Waiting...");
  const [uname, setUname] = useState("");
  const [id, setId] = useState("");
  const [students, setStudents] = useState({ id: 0, name: "aaa" });

  const getDerivedStateFromProps = (p) => {
    console.log("getDerivedStateFromProps loaded");
  };
  const componentDidMount = () => {
    console.log("Loaded");
  };

  const callAPI = () => {
    fetch("http://localhost:8080/" + uname, {
      method: "POST",
      // mode: "no-cors",
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
    })
      .then((response) => response.text())
      .then((data) => {
        console.log(data);
        setServerMessage(data);
      });
  };
  console.log("asdfas fsaldfh ashfs");
  const updateUname = (e) => {
    const kk = e.target.name;
    const val = e.target.value;
    setStudents((values) => ({ ...values, [kk]: val }));
  };
  const updateId = (e) => {
    const kk = e.target.name;
    const val = e.target.value;
    console.log(kk + " : " + val);
    setStudents((values) => ({ ...values, [kk]: val }));
  };

  const user = { id: 22, name: "kakakak" };
  console.log(JSON.stringify(user));

  const callAPIAdd = (e) => {
    fetch("http://localhost:8080", {
      method: "POST",
      // mode: "no-cors",
      body: JSON.stringify(students),
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
    })
      .then((response) => response.text())
      .then((data) => {
        console.log(data);
        setServerMessage(data);
      });
  };
  const [idResult, setIdResult] = useState("");
  const callAPIForVerifyingId = () => {
    console.log("Verifying ID : " + students.id);
    fetch("http://localhost:8080/verify/" + students.id)
      .then((response) => response.text())
      .then((data) => {
        data === "0"
          ? setIdResult("ID Available")
          : setIdResult("ID Not Available");
      });
  };
  return (
    <div style={{ color: "white" }}>
      <h1>This is Home ... </h1>
      <label>Enter ID : </label>{" "}
      <input
        type="text"
        value={students.id}
        onChange={updateId}
        name="id"
        onBlur={callAPIForVerifyingId}
      />
      <input type="text" value={idResult} readOnly />
      <br />
      <label>Enter Name : </label>
      <input
        type="text"
        value={students.name}
        onChange={updateUname}
        name="name"
      />
      <br />
      <button onClick={callAPI}>Call Student API 1</button>
      <button onClick={callAPIAdd}>Call Student API ADD</button>
      <div>
        <p>Message From API : {serverMessage}</p>
      </div>
    </div>
  );
}

export { Home };
