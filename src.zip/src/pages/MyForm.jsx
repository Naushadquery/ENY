import { useState } from "react";

function MyForm() {
  const myStyle = {
    backgroundColor: "yellow",
    color: "black",
  };

  const [userId, setUserId] = useState("");
  const [password, setPassword] = useState("");

  const doSubmission1 = (e) => {
    e.preventDefault();
    console.log("User ID : " + userId + " Password : " + password);
  };

  const doSubmission2 = function (e) {
    e.preventDefault();
    console.log("2");
  };

  return (
    <div style={myStyle}>
      <h1 style={{ textShadow: "2px 2px gray" }}>This is User Form</h1>
      <form action="" onSubmit={doSubmission1}>
        <table>
          <thead>
            <tr>
              <th colSpan={2}> User Form</th>
            </tr>
          </thead>
          <tbody style={{ color: "black" }}>
            <tr>
              <td>
                <label>User ID </label>
              </td>
              <td>
                <input
                  type="text"
                  name="userid"
                  id="userid"
                  value={userId}
                  onChange={(e) => {
                    setUserId(e.target.value);
                  }}
                  placeholder="Enter User Id"
                />
              </td>
            </tr>
            <tr>
              <td>
                <label>Password </label>
              </td>
              <td>
                <input
                  type="password"
                  name="password"
                  id="password"
																		value=""
                  onChange={(e) => {
                    setPassword(e.target.value);
                  }}
                  placeholder="XXXX"
                />
              </td>
            </tr>
            <tr>
              <td></td>
              <td>
                <input type="submit" value="Login" />
              </td>
            </tr>
          </tbody>
        </table>
      </form>
    </div>
  );
}

export { MyForm };
