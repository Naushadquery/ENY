import { useState } from "react";

function Calculator() {
  var labelForUname = "Enter Name ";
  var age = 18;

  const [uname, setUname] = useState("Enter User Name");
  const [res, setRes] = useState("");
  const display = (e) => {
    e.preventDefault();
    setRes(uname);
  };
  const updateData = (e) => {
    setUname(e.target.value);
  };
  return (
    <div>
      <h1>This is Calculator</h1>
      <form>
        <label htmlFor="uname">{labelForUname} : </label>
        <input
          type="text"
          name="uname"
          id="uname"
          placeholder={labelForUname}
          defaultValue={uname}
          onChange={updateData}
        />
        <input type="number" name="age" id="age" defaultValue={age} />
        <button onClick={display}> Display</button>
        <br />
        <h2>The Name Entered Is : {res}</h2>
      </form>
    </div>
  );
}

export { Calculator };
