import { useState } from "react";
import CurrencyInput, { formatValue } from "react-currency-input-field";

function Calculator() {
  const data = "12345.78";
  const formattedData = formatValue({
    value: data,
    intlConfig: { locale: "en-IN", currency: "INR" },
  });
  console.log(formattedData);
  return (
    <div>
      <CurrencyInput
        intlConfig={{ locale: "en-IN", currency: "INR" }}
        placeholder="₹"
        value={data}
      />
      <h1>This is Calculator {formattedData}</h1>
      <input type="text" value={formattedData} />

      {/* <form action="">
        <label htmlFor="uname">{labelForUname} : </label>
        <input
          type="text"
          name="uname"
          id="uname"
          placeholder={labelForUname}
          defaultValue={uname}
          onChange={updateData}
        />
        <input type="number" name="age" id="age" defaultValue={age} />
        <button onClick={display}> Display</button>
        <br />
        <h2>The Name Entered Is : {res}</h2>
      </form> */}
    </div>
  );
}

export { Calculator };
