import { useState } from "react";

function putValues(ename, evalue) {
  return { ...values, [ename]: evalue };
}

function MyForm2() {
  const myStyle = {
    backgroundColor: "yellow",
    color: "black",
  };

  const userInfo = {
    userId: "abc",
    password: "abc",
  };
  console.log(userInfo.userId);
  // const [userId, setUserId] = useState("");
  // const [password, setPassword] = useState("");
  const [userInputs, setUserInputs] = useState({ userId: "", password: "" });

  const updateInputs = (event) => {
    const ename = event.target.name;
    const evalue = event.target.value;

    setUserInputs((values) => {
      return { ...values, [ename]: evalue };
    });
  };

  const doSubmission1 = (e) => {
    e.preventDefault();
    //console.log("User ID : " + userId + " Password : " + password);
    console.log(userInputs);
  };

  return (
    <div style={myStyle}>
      <h1 style={{ textShadow: "2px 2px gray" }}>This is User Form 2</h1>
      <form action="" onSubmit={doSubmission1}>
        <table>
          <thead>
            <tr>
              <th colSpan={2}> User Form</th>
            </tr>
          </thead>
          <tbody style={{ color: "black" }}>
            <tr>
              <td>
                <label>User ID </label>
              </td>
              <td>
                <input
                  type="text"
                  name="userId"
                  id="userId"
                  value={userInputs.userId}
                  onChange={updateInputs}
                  placeholder="Enter User Id"
                />
              </td>
            </tr>
            <tr>
              <td>
                <label>Password </label>
              </td>
              <td>
                <input
                  type="password"
                  name="password"
                  id="password"
                  value={userInputs.password}
                  onChange={updateInputs}
                  placeholder="XXXX"
                />
              </td>
            </tr>
            <tr>
              <td></td>
              <td>
                <input type="submit" value="Login" />
              </td>
            </tr>
          </tbody>
        </table>
      </form>
    </div>
  );
}

export { MyForm2 };
