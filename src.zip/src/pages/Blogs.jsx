function Blogs() {
  return (
    <div>
      <h1>This is Blogs ... </h1>
    </div>
  );
}

export { Blogs };
