function NoPage() {
  return (
    <div>
      <h1>This is NoPage ... </h1>
    </div>
  );
}

export { NoPage };
