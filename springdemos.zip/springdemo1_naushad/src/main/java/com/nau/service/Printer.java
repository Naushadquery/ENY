package com.nau.service;

public class Printer {
	
	public void print(String message) {
		System.out.println("Your message is pritned " + message);
	}

}
