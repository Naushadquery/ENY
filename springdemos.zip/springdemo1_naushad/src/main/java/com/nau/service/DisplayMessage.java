package com.nau.service;

import org.springframework.beans.factory.annotation.Value;

public class DisplayMessage {
	
	private Printer printer ;
	
	public void setPrinter(Printer printer) {
		this.printer = printer;
	}

	@Value("${message}")
	private String message;
	
	@Value("${name:kkk}")
	private String name;
	
	
	
	public DisplayMessage() {
		System.out.println("DisplayMessage Object Created");
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void printMessage() {
		printer.print(message);
	}
//	public void displayMessage() {
//		System.out.println(this.message + " " + name); 
//	}

}
