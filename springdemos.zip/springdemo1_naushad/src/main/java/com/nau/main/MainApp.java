package com.nau.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.nau.config.BeanConfiguration;
import com.nau.service.DisplayMessage;

public class MainApp {

	public static void main(String[] args) {
//
//		try (ConfigurableApplicationContext applicationContext = new ClassPathXmlApplicationContext("beans.xml")) {
//			DisplayMessage dm = applicationContext.getBean(DisplayMessage.class);
//			dm.setMessage("Hello Bondhoo");
//			dm.displayMessage();
//		}

	//	ApplicationContext applicationContext1 = new ClassPathXmlApplicationContext("beans.xml");// open factory
		ApplicationContext applicationContext1 = new  AnnotationConfigApplicationContext(BeanConfiguration.class);
		System.out.println("Factory Ready with Objects");
		DisplayMessage dm1 = applicationContext1.getBean(DisplayMessage.class);
		System.out.println(dm1.hashCode());
		//dm1.setMessage("HEllo Babu");
	//	dm1.displayMessage();
		dm1.printMessage();
	//	DisplayMessage dm2 = applicationContext1.getBean(DisplayMessage.class);
	//	System.out.println(dm2.hashCode());
	//	dm2.setMessage("HEllo Baba");
		//dm2.displayMessage();
	}

}
