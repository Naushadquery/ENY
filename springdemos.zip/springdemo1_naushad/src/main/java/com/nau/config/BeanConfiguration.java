package com.nau.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;

import com.nau.service.DisplayMessage;
import com.nau.service.Printer;

@Configuration
@PropertySource("classpath:message.properties")
public class BeanConfiguration {
	
	@Bean
	@Lazy(value = true)
	@Scope("singleton")
	public DisplayMessage getDisplayMessage() {
		DisplayMessage dm = new DisplayMessage();
	//	dm.setMessage("HEllo BEan Config");
		dm.setPrinter(getPrinter());
		return dm;
	}
	
	@Bean
	public Printer getPrinter() {
		return new Printer();
	}
}
