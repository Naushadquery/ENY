package com.nau.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.nau.beans.SpellChecker;
import com.nau.beans.TextEditor;

@Configuration
@ComponentScan(basePackages = {"com.nau.beans"})
public class MyConfig {
	
}
