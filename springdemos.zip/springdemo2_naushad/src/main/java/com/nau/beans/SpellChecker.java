package com.nau.beans;

import org.springframework.stereotype.Component;

@Component
public class SpellChecker {
	
	public String spellCheck(String word) {
		return "The word, " + word  +  " is OK";
	}

}
