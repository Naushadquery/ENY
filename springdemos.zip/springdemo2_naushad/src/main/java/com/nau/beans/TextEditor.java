package com.nau.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TextEditor {
	
	@Autowired
	private SpellChecker checker;

	public void checkSpelling(String word) {
		String c =checker.spellCheck(word);
		System.out.println(c);
	}
}
