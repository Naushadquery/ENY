package com.nau;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.nau.beans.TextEditor;
import com.nau.config.MyConfig;

public class MainApp {

	public static void main(String[] args) {

		var x = new AnnotationConfigApplicationContext(MyConfig.class);
		TextEditor te = x.getBean(TextEditor.class);
		te.checkSpelling("popopopo");
	}

}
