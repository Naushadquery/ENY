package com.nau.dao;

import java.util.Optional;

import com.nau.model.Login;

public interface AdminDaoInterface{
	void addLogin(Login login);
	void deleteLogin(Integer userId);
	void updateAdminLogin();
	Optional<Login> getUserById(Integer userId);
}
