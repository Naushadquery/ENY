package com.nau.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import com.nau.model.Login;
import com.nau.model.LoginType;

public class LoginDao implements AdminDaoInterface,EmployeeDaoInterface {
	private static Set<Login> logins = new HashSet<>();
	static {
		File file = new File("logindata.ser");
		if (file.exists()) {
			try (FileInputStream fileInputStream = new FileInputStream(file);
					ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream)) {
				logins = (HashSet<Login>)(objectInputStream.readObject());
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		} else {
			logins.add(new Login(111, "u111", LoginType.USER, "Naushad", "Akthar"));
			logins.add(new Login(112, "u111", LoginType.USER, "Sudipta", "Sasmal"));
			logins.add(new Login(222, "a222", LoginType.ADMIN, "RK", "Prgyajit"));
			logins.add(new Login(221, "a221", LoginType.ADMIN, "Priyanka", "Roy"));
		}
	}

	@Override
	public void addLogin(Login login) {
		logins.add(login);
	}

	@Override
	public void deleteLogin(Integer userId) {

	}

	@Override
	public void updateUserLogin() {

	}

	@Override
	public void updateAdminLogin() {

	}

	@Override
	public Optional<Login> getUserById(Integer userId) {
		Optional<Login> optional = logins.stream().filter((login) -> login.getUserId().equals(userId)).findFirst();
		return optional;
	}

	public static void saveLogin() {
		try (FileOutputStream fileOutputStream = new FileOutputStream("logindata.ser");
				ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream)) {
			objectOutputStream.writeObject(logins);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

//	public Login getUserById(Integer userId) {
//		
//		for(Login login : logins) {
//			if(login.getUserId().equals(userId)) {
//				return login;
//			}
//		}
//		return null;
//		
//	}
}
