package com.nau.dao;

public interface EmployeeDaoInterface {
	void updateUserLogin(); // user // 
}

