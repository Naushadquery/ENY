package com.nau.view;

import java.util.Scanner;

import com.nau.dao.AdminDaoInterface;
import com.nau.dao.EmployeeDaoInterface;
import com.nau.dao.LoginDao;

public class EmployeeView {
	
	private Scanner input = new Scanner(System.in);
	private EmployeeDaoInterface loginDao  = new LoginDao();
	
	public EmployeeView() {
		System.out.println("In Employee View");
	}
	
	

}
