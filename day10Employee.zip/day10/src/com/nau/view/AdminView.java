package com.nau.view;

import java.util.Scanner;

import com.nau.dao.AdminDaoInterface;
import com.nau.dao.LoginDao;
import com.nau.model.Login;
import com.nau.model.LoginType;

public class AdminView {

	private Scanner input = new Scanner(System.in);
	private AdminDaoInterface loginDao = new LoginDao();

	public AdminView() {
		System.out.println("Admin View");
		viewPanel();
	}

	private void viewPanel() {
		System.out.println("1. Add User");
		System.out.println("Enter User ID");
		String userId = input.next();
		System.out.println("Enter Password");
		String password = input.next();
		System.out.println("Enter Type :  USER | ADMIN | MANAGER "  );
		String type = input.next();
		type = type.toUpperCase();
		LoginType loginType = LoginType.USER;
		switch (type) {
		case "USER": {
			loginType = LoginType.USER;
			break;
		}
		case "ADMIN": {
			loginType = LoginType.ADMIN;
			break;
		}
		case "MANAGER": {
			loginType = LoginType.MANAGER;
			break;
		}
		default: {
			System.out.println("PROPER TYPE NOT GIVEN");
		}
		}

		System.out.println("Enter First Name : ");
		String fName = input.next();
		System.out.println("Enter Lass Name");
		String lName = input.next();
		Login login = new Login(Integer.valueOf(userId), password, loginType, fName, lName);
		loginDao.addLogin(login);
		System.out.println("Saved");

	}

}
