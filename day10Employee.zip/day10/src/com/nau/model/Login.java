package com.nau.model;

import java.io.Externalizable;
import java.io.Serializable;
import java.util.Objects;

public class Login implements Serializable{
//	public class Login implements Externalizable{
	private static final long serialVersionUID = 1L;
	private Integer userId;
	private String password;
	private LoginType type; // user/admin // ENUM
	private String fName;
	private String lName;
	
	public Login() {
	}

	

	public Login(Integer userId, String password, LoginType type, String fName, String lName) {
		super();
		this.userId = userId;
		this.password = password;
		this.type = type;
		this.fName = fName;
		this.lName = lName;
	}



	public String getfName() {
		return fName;
	}



	public void setfName(String fName) {
		this.fName = fName;
	}



	public String getlName() {
		return lName;
	}



	public void setlName(String lName) {
		this.lName = lName;
	}



	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public LoginType getType() {
		return type;
	}

	public void setType(LoginType type) {
		this.type = type;
	}

	

	@Override
	public String toString() {
		return "Login [userId=" + userId + ", password=" + password + ", type=" + type + ", fName=" + fName + ", lName="
				+ lName + "]";
	}



	@Override
	public int hashCode() {
		return Objects.hash(userId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Login other = (Login) obj;
		return Objects.equals(userId, other.userId);
	}

//	@Override
//	public void writeExternal(ObjectOutput out) throws IOException {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
//		// TODO Auto-generated method stub
//		
//	}
	
	
}
